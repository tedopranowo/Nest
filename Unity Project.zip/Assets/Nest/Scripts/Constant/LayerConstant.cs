﻿public enum LayerConstant
{
    kDefault = 0,
    kTransparentFX = 1,
    kIgnoreRaycasat = 2,
    kWater = 4,
    kUI = 5,
    kFlying = 8,
}